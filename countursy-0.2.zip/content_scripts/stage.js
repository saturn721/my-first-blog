var video = document.getElementById('video');
console.log(video);
if (video.paused == true) {
    // Play the video
    video.play();


  } else {
    // Pause the video
    video.pause();


};
